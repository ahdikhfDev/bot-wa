import { Client } from 'ssh2';
import dotenv from 'dotenv';
dotenv.config();

const conn = new Client();

const config = {
    host: '192.168.1.198',
    port: 22,
    username: 'root',
    password: 'ahdikhf2006'
};

conn.on('ready', () => {
    console.log('✅ SSH Connection established!');
    console.log('🔍 Checking for any hidden node processes on STB...');
    conn.exec('ps aux | grep node', (err, stream) => {
        if (err) throw err;
        stream.on('data', (data) => {
            console.log(data.toString());
        }).on('close', (code) => {
            conn.end();
        });
    });
}).on('error', (err) => {
    console.error('❌ SSH Error:', err.message);
}).connect(config);
